# A02 Prep

* The blackjack game will be your best preparation for what to expect on the actual assessment. Read the specs carefully and follow along.
* For additional practice with specs, check out [this TTT game](https://github.com/MrPowers/tic_tac_toe/).
