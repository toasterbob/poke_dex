/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	const FollowToggle = __webpack_require__(1);
	const UsersSearch = __webpack_require__(3);
	
	$(() => {
	  $("button.follow-toggle").each((idx, el) => {
	    const ftEl = new FollowToggle(el);
	
	  });
	  $("nav.users-search").each((idx, el) => {
	    const usersSearch = new UsersSearch(el);
	  });
	});


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	const APIUtil = __webpack_require__(2);
	
	class FollowToggle {
	  constructor(el) {
	    this.$el = $(el);
	    this.followState = this.$el.attr("data-follow-state");
	    this.userId = this.$el.attr("data-user-id");
	    this.render();
	    this.$el.click(this.handleClick.bind(this));
	  }
	
	  render() {
	    if (this.followState === "unfollowing" ||
	        this.followState === "following") {
	          this.$el.prop("disabled", true);
	    } else {
	      this.$el.prop("disabled", false);
	      if (this.followState === 'unfollowed') {
	        this.$el.html("Follow!") ;
	      } else {
	        this.$el.html("Unfollow!");
	      }
	    }
	  }
	
	  handleClick(e) {
	    e.preventDefault();
	    const follows = this.followState === 'followed';
	  
	    let toggleFollow;
	    if (follows) {
	      this.followState = "unfollowing";
	      this.render();
	      toggleFollow = APIUtil.unfollowUser;
	    } else {
	      this.followState = "following";
	      this.render();
	      toggleFollow = APIUtil.followUser;
	    }
	    const onSuccess = obj => {
	      this.toggleFollowState();
	      this.render();
	    };
	    const onFailure = obj => console.log("YOU FAILED");
	    toggleFollow(this.userId).then(onSuccess).fail(onFailure);
	  }
	
	  toggleFollowState() {
	    if (this.followState === "followed" || this.followState === "unfollowing") {
	      this.followState = "unfollowed";
	    } else {
	      this.followState = "followed";
	    }
	  }
	
	}
	
	module.exports = FollowToggle;


/***/ },
/* 2 */
/***/ function(module, exports) {

	const APIUtil = {
	  followUser: id => {
	    return $.ajax({
	      method: 'POST',
	      dataType: "json",
	      url: `/users/${id}/follow`,
	    });
	  },
	
	  unfollowUser: id => {
	    return $.ajax({
	      method: 'DELETE',
	      dataType: "json",
	      url: `/users/${id}/follow`,
	    });
	  },
	
	  searchUsers(queryVal, successCallback) {
	    return $.ajax({
	      url: '/users/search',
	      method: 'GET',
	      dataType: "json",
	      data: {queryVal},
	      //success: successCallback,
	    });
	  }
	};
	
	module.exports = APIUtil;


/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	const APIUtil = __webpack_require__(2);
	
	class UsersSearch {
	
	  constructor(el) {
	    this.$el = $(el);
	    this.$ul = this.$el.find("ul");
	    this.input = this.$el.find("input");
	    this.$el.on("input", this.handleInput.bind(this));
	  }
	
	  handleInput() {
	    const query = this.input.val();
	    if (query === "") { this.renderResults([]); return; }
	    //console.log(query);
	    APIUtil.searchUsers(query).then(users => this.renderResults(users));
	  }
	
	  renderResults(res) {
	    console.log(res);
	    this.$ul.empty();
	    for (let i = 0; i < res.length; i++) {
	      const userObj = res[i];
	      const link = `<a href='/users/${userObj.id}'>${userObj.username}</a>`;
	      const $li = $('li').append($(link));
	      console.log($li);
	      this.$ul.append($li);
	    }
	  }
	}
	
	module.exports = UsersSearch;


/***/ }
/******/ ]);
//# sourceMappingURL=bundle.js.map