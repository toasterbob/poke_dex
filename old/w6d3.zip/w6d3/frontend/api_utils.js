const APIUtil = {
  followUser: id => {
    return $.ajax({
      method: 'POST',
      dataType: "json",
      url: `/users/${id}/follow`,
    });
  },

  unfollowUser: id => {
    return $.ajax({
      method: 'DELETE',
      dataType: "json",
      url: `/users/${id}/follow`,
    });
  },

  searchUsers(queryVal, successCallback) {
    return $.ajax({
      url: '/users/search',
      method: 'GET',
      dataType: "json",
      data: {queryVal},
      //success: successCallback,
    });
  }
};

module.exports = APIUtil;
