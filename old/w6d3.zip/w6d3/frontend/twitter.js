const FollowToggle = require("./follow_toggle.js");
const UsersSearch = require("./users_search.js");

$(() => {
  $("button.follow-toggle").each((idx, el) => {
    const ftEl = new FollowToggle(el);

  });
  $("nav.users-search").each((idx, el) => {
    const usersSearch = new UsersSearch(el);
  });
});
