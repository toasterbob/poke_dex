const APIUtil = require("./api_utils.js");

class FollowToggle {
  constructor(el) {
    this.$el = $(el);
    this.followState = this.$el.attr("data-follow-state");
    this.userId = this.$el.attr("data-user-id");
    this.render();
    this.$el.click(this.handleClick.bind(this));
  }

  render() {
    if (this.followState === "unfollowing" ||
        this.followState === "following") {
          this.$el.prop("disabled", true);
    } else {
      this.$el.prop("disabled", false);
      if (this.followState === 'unfollowed') {
        this.$el.html("Follow!") ;
      } else {
        this.$el.html("Unfollow!");
      }
    }
  }

  handleClick(e) {
    e.preventDefault();
    const follows = this.followState === 'followed';
  
    let toggleFollow;
    if (follows) {
      this.followState = "unfollowing";
      this.render();
      toggleFollow = APIUtil.unfollowUser;
    } else {
      this.followState = "following";
      this.render();
      toggleFollow = APIUtil.followUser;
    }
    const onSuccess = obj => {
      this.toggleFollowState();
      this.render();
    };
    const onFailure = obj => console.log("YOU FAILED");
    toggleFollow(this.userId).then(onSuccess).fail(onFailure);
  }

  toggleFollowState() {
    if (this.followState === "followed" || this.followState === "unfollowing") {
      this.followState = "unfollowed";
    } else {
      this.followState = "followed";
    }
  }

}

module.exports = FollowToggle;
