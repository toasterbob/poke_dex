const APIUtil = require('./api_utils.js');

class UsersSearch {

  constructor(el) {
    this.$el = $(el);
    this.$ul = this.$el.find("ul");
    this.input = this.$el.find("input");
    this.$el.on("input", this.handleInput.bind(this));
  }

  handleInput() {
    const query = this.input.val();
    if (query === "") { this.renderResults([]); return; }
    //console.log(query);
    APIUtil.searchUsers(query).then(users => this.renderResults(users));
  }

  renderResults(res) {
    console.log(res);
    this.$ul.empty();
    for (let i = 0; i < res.length; i++) {
      const userObj = res[i];
      const link = `<a href='/users/${userObj.id}'>${userObj.username}</a>`;
      const $li = $('li').append($(link));
      console.log($li);
      this.$ul.append($li);
    }
  }
}

module.exports = UsersSearch;
