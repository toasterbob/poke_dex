class Api::InvitationsController < ApplicationController
end
