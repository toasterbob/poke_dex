require 'rails_helper'

RSpec.describe PokemonController, type: :controller do

end
