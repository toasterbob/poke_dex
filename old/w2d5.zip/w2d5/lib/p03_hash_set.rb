require_relative 'p02_hashing'

class HashSet
  attr_reader :count, :store

  def initialize(num_buckets = 8)
    @store = Array.new(num_buckets) { Array.new }
    @count = 0
  end

  def insert(key)
    @store[key.hash % num_buckets] << key
    @count += 1
    resize! if @count > num_buckets 
  end

  def include?(key)
    @store[key.hash % num_buckets].include?(key)
  end

  def remove(key)
    @store.delete_at(key.hash % num_buckets)
    @count -= 1
  end

  private

  def [](num)
    @store[key.hash % num_buckets]
  end

  def num_buckets
    @store.length
  end

  def resize!
    old_storage = @store
    @count = 0
    @store = Array.new(num_buckets * 2) { Array.new }
    old_storage.flatten.each {|num| insert(num)}
  end
end
