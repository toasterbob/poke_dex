class Link
  attr_accessor :key, :val, :next, :prev

  def initialize(key = nil, val = nil)
    @key = key
    @val = val
    @next = nil
    @prev = nil
  end

  def to_s
    "#{@key}: #{@val}"
  end

  def remove
    # optional but useful, connects previous link to next link
    # and removes self from list.
    @prev.next = @next
  end
end

class LinkedList
  include Enumerable

  attr_reader :head, :tail
  def initialize
    @head = Link.new
    @tail = Link.new
    @head.next = @tail
    @tail.prev = @head
  end

  def [](i)
    each_with_index { |link, j| return link if i == j }
    nil
  end

  def first
    self.head
  end

  def last
    self.tail
  end

  def empty?
    return true if @head.val == nil && @tail.val == nil
    false
  end

  def get(key)
    current_link = @head
    until current_link.next == nil
      if current_link.key == key
        return current_link.val
      elsif @tail.key == key
        return @tail.val
      else
        current_link = current_link.next
      end
    end

    nil
  end

  def include?(key)
    current_link = @head.next

    if @head.key == key
      return true
    elsif @tail.key == key
      return true
    else
      until current_link.next == nil
        if current_link.key == key
          return true
        else
          current_link = current_link.next
        end
      end
    end

    false
  end

  def append(key, val)
    new_link = Link.new(key, val)
    if @head.val == nil
      @head = new_link
      @head.next = @tail
    elsif @tail.val == nil
      @tail = new_link
      @tail.prev = @head
      @head.next = @tail
    else
      previous_tail = @tail
      @head.next = previous_tail
      previous_tail.prev = @head
      @tail = new_link
      previous_tail.next = @tail
      @tail.prev = previous_tail
    end
  end

  def update(key, val)
    current_link = @head
    if current_link.key == key
      current_link.val = val
    else
      current_link = current_link.next
    end
  end

  def remove(key)
    current_link = @head.next

    if @head.key == key
      @head.prev = nil
      @head = @head.next
    elsif @tail.key == key
      @tail.prev.next = nil
      @tail = @tail.prev
    else
      until current_link.next == nil
        if current_link.key == key
          current_link.prev.next = current_link.next
          current_link.next.prev = current_link.prev
          current_link.next = nil
          current_link.prev = nil
        else
          current_link = current_link.next
        end
      end
    end

  end

  def each(&prc)
    current_link = @head
    until current_link.next == nil
      prc.call(current_link)
      current_link = current_link.next
    end
    prc.call(@tail)

  end

  def to_s
    inject([]) { |acc, link| acc << "[#{link.key}, #{link.val}]" }.join(", ")
  end
end
