class TodosController < ApplicationController
  def title:string
  end

  def body:string
  end
end
