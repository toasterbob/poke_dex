Rails.application.routes.draw do
  get 'todos/title:string'

  get 'todos/body:string'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
