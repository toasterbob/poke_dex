import React from 'react';
import Tabs from './tabs';

const obj = [{title: "new title", content: "content"} ];

const Congrats = () => (
  <h1><Tabs panes={obj}/></h1>
);

export default Congrats;
