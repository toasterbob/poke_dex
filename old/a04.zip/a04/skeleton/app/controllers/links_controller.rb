class LinksController < ApplicationController

  
end
